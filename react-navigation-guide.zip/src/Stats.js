import React from 'react';
function Stats() {
  return <h2>Dashboard Stats</h2>;
}
export default Stats;