import React from 'react';
function Profile() {
  return <h2>Dashboard Profile</h2>;
}
export default Profile;