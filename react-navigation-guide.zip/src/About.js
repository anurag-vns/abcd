import React from 'react';
function About() {
  return <h2>About Us Page</h2>;
}
export default About;